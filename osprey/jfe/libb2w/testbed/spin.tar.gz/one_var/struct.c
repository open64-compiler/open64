struct colson{
  int a;
  int b;
  int c;
};

int main(){
  return 3;
}
