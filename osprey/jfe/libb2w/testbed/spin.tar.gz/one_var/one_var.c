int main(){
  int myvar;
  myvar = 2;
  return myvar;
}
