int main(){
  int myvar = 2;
  int myanothervar = 4;
  return myvar+myanothervar;
}
